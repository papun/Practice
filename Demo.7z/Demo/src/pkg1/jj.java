package pkg1;

import org.openjdk.jol.vm.VM;

public class jj {
    public static void main(String[] args) {

        String c = new String("abc");
        String d = new String("abc");
        String a = "abc";
        String b = "abc";

        System.out.println(VM.current().addressOf(a));
        System.out.println(VM.current().addressOf(b));
        System.out.println(VM.current().addressOf(c));
        System.out.println(VM.current().addressOf(d));
    }
}