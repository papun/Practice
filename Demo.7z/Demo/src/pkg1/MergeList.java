package pkg1;

class ListNode {
      int val;
      ListNode next;
      ListNode() {}
      ListNode(int val) { this.val = val; }
      ListNode(int val, ListNode next) { this.val = val; this.next = next; }
  }
public class MergeList {
    public static ListNode mergeTwoLists(ListNode list1, ListNode list2) {

        return null;
    }
    public static void main(String[] args) {

    }
}
